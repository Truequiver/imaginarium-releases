Learning how to learn — an Imaginarium content pack (app 2.7)

Open in Imaginarium with File > Open file, then choose "Add to my city".
It adds a city called "Learning how to learn" with 11 worlds. Start in "Start Here: How Memory Works".

Pick a learner (the person icon at the top) to save Checkpoint progress and unlock worlds in order.
Every item has credits (Made by, Source, Source link, License): open the Credits button to see them all.
Web videos are linked, not stored. Original writing, diagrams and the neuron model: CC BY 4.0, Truequiver.
